from parse_rest.datatypes import Object

class Tweet(Object):
    pass
